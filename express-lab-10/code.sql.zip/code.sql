select * from product where id=2;
select * from manufacturer where id=1;
select * from product where manufacturer_id=1;
select product.*,manufacturer.name as manufacturer_name
from product left join manufacturer 
on product.manufacturer_id=manufacturer.id;
select product.*,manufacturer.name as manufacturer_name
from product left join manufacturer 
on product.manufacturer_id=manufacturer.id
where product.id=2;
select product.*,manufacturer.name as manufacturer_name
from product left join manufacturer 
on product.manufacturer_id=manufacturer.id
where product.manufacturer_id=1;